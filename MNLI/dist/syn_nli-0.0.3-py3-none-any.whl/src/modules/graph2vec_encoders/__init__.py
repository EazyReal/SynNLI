from .graph2vec_encoder import (
    Graph2VecEncoder,
)
from .attention import GlobalAttention