#!/usr/bin/env python
# set loggers here? see allenlp main
#import src.config

import os, sys

def run():
    print(__file__)
    print(os.path.dirname(os.path.realpath(__file__)))
    return


if __name__ == "__main__":
    run()