"""
modification of RGCNConv so that it returns sum of msg
actually by simply setting root_weight False and bias = False if enough
"""
