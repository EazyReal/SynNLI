"""
https://github.com/allenai/allennlp/blob/master/allennlp/modules/seq2seq_encoders/pytorch_seq2seq_wrapper.py
"""

from src.modules.graph2graph_encoders.graph2graph_encoder import Graph2GraphEncoder 